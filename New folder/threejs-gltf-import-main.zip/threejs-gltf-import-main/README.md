# threejs-gltf-import

Demo app for importing a .gltf model using Three.js

## Demo

https://dgreenheck.github.io/threejs-gltf-import/

## Tutorial

Check out the [step-by-step tutorial](https://youtu.be/aOQuuotM-Ww) on my YouTube channel!
